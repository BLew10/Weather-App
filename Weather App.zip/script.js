var farhenheitCelsius = document.querySelector("#temp-options");
var highToday = document.querySelector("#high-today");
var lowToday = document.querySelector("#low-today");
var highTom = document.querySelector("#high-tom");
var lowTom = document.querySelector("#low-tom");
var high3 = document.querySelector("#high-3");
var low3 = document.querySelector("#low-3");
var high4 = document.querySelector("#high-4");
var low4 = document.querySelector("#low-4");

var temps = [highToday, lowToday, highTom, lowTom, high3, low3, high4, low4];

var initTemps = [highToday.innerHTML, lowToday.innerHTML, highTom.innerHTML, lowTom.innerHTML, high3.innerHTML, low3.innerHTML, high4.innerHTML, low4.innerHTML]

function change() {
    if (farhenheitCelsius.value === "celsius") {
        for (var i = 0; i < temps.length; i++){
            temps[i].innerHTML = ` ${Math.round((parseInt(temps[i].innerHTML)-32)*(5/9))} &#8451`
        }
        // 
    } else if (farhenheitCelsius.value === "fahrenheit"){
        for (var i = 0; i < temps.length; i++){
            temps[i].innerHTML = `${parseInt(initTemps[i])} &#8457`;
        }
    }
}


function removeCookies() {
    document.querySelector(".cookies").remove();
}


